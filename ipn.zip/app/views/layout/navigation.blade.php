<nav>
	<ul>
		<li><a href="{{URL::route("home")}}">Inicio</a></li>
		<li>●</li>
		<li><a href="{{URL::route("galeria")}}">Galeria</a></li>
		<li>●</li>
		<li><a href="{{URL::route("agenda")}}">Agenda</a></li>
		<li>●</li>
		<li><a href="{{URL::route("contacto")}}">Contacto</a></li>
		<li>●</li>
		<li><a href="{{URL::route("propuestas")}}">Registro de propuestas</a></li>
		<li>●</li>
		<li><a href="#">Patrocinadores</a></li>
		{{-- <li><a href="{{URL::route("accountSignIn")}}">Sign In</a></li> --}}
	</ul>
</nav>