<?php

return array(

    /*
    |--------------------------------------------------------------------------
    | Cloudinary API configuration
    |--------------------------------------------------------------------------
    |
    | Before using Cloudinary you need to register and get some detail
    | to fill in below, please visit cloudinary.com.
    |
    */

    'cloudName'  => 'dmgd5md6c',
    'baseUrl'    => 'http://res.cloudinary.com/dmgd5md6c',
    'secureUrl'  => 'https://res.cloudinary.com/dmgd5md6c',
    'apiBaseUrl' => 'https://api.cloudinary.com/v1_1/dmgd5md6c',
    'apiKey'     => '654636864945651',
    'apiSecret'  => '80gMY9nR5Yi0J1VUyTyLHaOVRZ8',

    /*
    |--------------------------------------------------------------------------
    | Default image scaling to show.
    |--------------------------------------------------------------------------
    |
    | If you not pass options parameter to Cloudy::show the default
    | will be replaced.
    |
    */

    'scaling'    => array(
    )

);
